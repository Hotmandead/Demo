/*
 See LICENSE folder for this sample’s licensing information.
 */

import Foundation
import ThemeKit

struct DailyScrum {
    var title: String
    var attendees: [String]
    var lengthInMinutes: Int
    var theme: Theme
}
